
<?php
// Este script gera um hash seguro para a senha que você definir.

$senhaSimples = 'admin123';
$hash = password_hash($senhaSimples, PASSWORD_DEFAULT);

echo "<h1>Gerador de Hash de Senha</h1>";
echo "<p>Use o código abaixo para atualizar seu banco de dados.</p>";
echo "<hr>";
echo "<b>Senha simples:</b> " . htmlspecialchars($senhaSimples) . "<br><br>";
echo "<b>Seu novo código de senha (hash) gerado:</b><br>";
echo "<textarea rows='3' cols='80' readonly onclick='this.select();' style='font-size:16px;'>" . $hash . "</textarea>";
echo "<p><i>Clique na caixa de texto para selecionar tudo e copie (Ctrl+C).</i></p>";
?>