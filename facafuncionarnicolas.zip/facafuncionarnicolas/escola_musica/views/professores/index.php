<main class="container">
    <div class="main-header">
        <h2>Gestão de Professores</h2>
        <a href="<?php echo BASE_URL; ?>/index.php?url=professor/create" class="btn">Novo Professor</a>
    </div>

    <table>
        <thead>
            <tr>
                <th>Nome</th>
                <th>Email</th>
                <th>Telefone</th>
                <th>Ações</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($professores as $prof): ?>
            <tr>
                <td><?php echo htmlspecialchars($prof['nome']); ?></td>
                <td><?php echo htmlspecialchars($prof['email']); ?></td>
                <td><?php echo htmlspecialchars($prof['telefone']); ?></td>
                <td class="actions">
                    <a href="<?php echo BASE_URL; ?>/index.php?url=professor/edit/<?php echo $prof['id']; ?>">Editar</a>
                    <a href="<?php echo BASE_URL; ?>/index.php?url=professor/delete/<?php echo $prof['id']; ?>" 
                       onclick="return confirm('Tem certeza que deseja excluir?');">
                       Excluir
                    </a>
                </td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</main>