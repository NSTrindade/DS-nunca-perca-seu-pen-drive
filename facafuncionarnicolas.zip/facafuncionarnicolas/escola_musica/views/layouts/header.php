<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Escola de Música</title>
    <link rel="stylesheet" href="<?php echo BASE_URL; ?>/styles/style.css">
</head>
<body>
    <header>
        <nav class="container">
            <a href="<?php echo BASE_URL; ?>/index.php?url=home" class="logo">🎵 Escola de Música</a>
            <ul>
                <li><a href="<?php echo BASE_URL; ?>/index.php?url=home">Dashboard</a></li>
                <li><a href="<?php echo BASE_URL; ?>/index.php?url=professor">Professores</a></li>
                <li><a href="<?php echo BASE_URL; ?>/index.php?url=aluno">Alunos</a></li>
                <li><a href="<?php echo BASE_URL; ?>/index.php?url=auth/logout">Sair</a></li>
            </ul>
        </nav>
    </header>