<main class="container">
    <h2>Bem-vindo(a), <?php echo htmlspecialchars($_SESSION['user_nome']); ?>!</h2>
    <p>Este é o painel de controle da Escola de Música. Use o menu acima para navegar pelas seções do sistema.</p>
    
    <div class="dashboard-widgets">
        <div class="widget">
            <h3>Professores</h3>
            <p>Gerencie os professores cadastrados.</p>
            <a href="<?php echo BASE_URL; ?>/index.php?url=professor" class="btn">Ver Professores</a>
        </div>
        <div class="widget">
            <h3>Alunos</h3>
            <p>Gerencie os alunos da escola.</p>
            <a href="#" class="btn disabled">Em Breve</a>
        </div>
        <div class="widget">
            <h3>Turmas</h3>
            <p>Crie e administre as turmas.</p>
            <a href="#" class="btn disabled">Em Breve</a>
        </div>
    </div>
</main><main class="container">
    <h2>Bem-vindo(a), <?php echo htmlspecialchars($_SESSION['user_nome']); ?>!</h2>
    <p>Este é o painel de controle da Escola de Música. Use o menu acima para navegar pelas seções do sistema.</p>
    
    <div class="dashboard-widgets">
        <div class="widget">
            <h3>Professores</h3>
            <p>Gerencie os professores cadastrados.</p>
            <a href="<?php echo BASE_URL; ?>/index.php?url=professor" class="btn">Ver Professores</a>
        </div>
        <div class="widget">
            <h3>Alunos</h3>
            <p>Gerencie os alunos da escola.</p>
            <a href="#" class="btn disabled">Em Breve</a>
        </div>
        <div class="widget">
            <h3>Turmas</h3>
            <p>Crie e administre as turmas.</p>
            <a href="#" class="btn disabled">Em Breve</a>
        </div>
    </div>
</main>