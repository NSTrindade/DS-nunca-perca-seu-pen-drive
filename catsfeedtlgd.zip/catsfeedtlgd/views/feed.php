<?php
session_start();
require '../model/db.php';

// Verifica se está logado
if (!isset($_SESSION['usuario_id'])) {
    header("Location: ../views/login.php");
    exit;
}

// Consulta que pega posts junto com dados do usuário
$sql = "
    SELECT p.imagem, p.legenda, p.data_post, u.email
    FROM posts p
    JOIN usuario u ON p.usuario_id = u.id
    ORDER BY p.data_post DESC
";

$result = $conn->query($sql);

$posts = [];
if ($result && $result->num_rows > 0) {
    $posts = $result->fetch_all(MYSQLI_ASSOC);
}
$conn->close();
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Feed</title>
    <link rel="stylesheet" href="../styles/stylefeed.css">
</head>
<body>

<header>
    <img src="../assets/logo.png">
    <div class="menuToggle">
        <div class="toggle"></div>
    </div>
</header>

<div class="content-wrapper">
    <a href="../views/novo_post.php">Novo Post</a>

    <div class="feed-container">
        <?php if (empty($posts)): ?>
            <p>Nenhum post encontrado.</p>
        <?php else: ?>
            <?php foreach ($posts as $post): ?>
                <div class="post">
                    
                    <img src="<?= htmlspecialchars($post['imagem'], ENT_QUOTES, 'UTF-8') ?>" alt="Imagem do post">

                    <div class="post-content">
                        <div class="email">
                            <?= htmlspecialchars($post['email'], ENT_QUOTES, 'UTF-8') ?>
                        </div>
                        <div class="legenda">
                            <?= nl2br(htmlspecialchars($post['legenda'], ENT_QUOTES, 'UTF-8')) ?>
                        </div>
                        <div class="data">
                            <?= date('d/m/Y - H:i', strtotime($post['data_post'])) ?>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        <?php endif; ?>
    </div>
</div>

<script src="../scripts/login.js"></script>
</body>
</html>