let menuToggle = document.querySelector(".menuToggle");

menuToggle.addEventListener("click", ()=>{
    let toggle = document.querySelector(".toggle");
    toggle.classList.toggle("active")
})