<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Login - Escola de Música</title>
    <link rel="stylesheet" href="<?php echo BASE_URL; ?>/styles/style.css">
</head>
<body class="login-page">
    <div class="login-container">
        <h2>🎵 Acesso ao Sistema</h2>
        <?php if (isset($error)): ?>
            <p class="error"><?php echo $error; ?></p>
        <?php endif; ?>
        <form action="<?php echo BASE_URL; ?>/index.php?url=auth/process_login" method="POST">
            <div class="form-group">
                <label for="email">Email:</label>
                <input type="email" id="email" name="email" required>
            </div>
            <div class="form-group">
                <label for="senha">Senha:</label>
                <input type="password" id="senha" name="senha" required>
            </div>
            <button type="submit" class="btn">Entrar</button>
        </form>
    </div>
</body>
</html>