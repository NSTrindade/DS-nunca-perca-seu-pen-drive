<footer class="container">
        <p>&copy; <?php echo date('Y'); ?> Escola de Música. Todos os direitos reservados.</p>
    </footer>
    <script src="<?php echo BASE_URL; ?>/scripts/script.js"></script>
</body>
</html>