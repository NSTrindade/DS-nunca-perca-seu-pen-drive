<main class="container">
    <h2>Nova Turma</h2>
    <form action="<?php echo BASE_URL; ?>/index.php?url=turma/store" method="POST">
        <div class="form-group">
            <label for="curso_id">Curso:</label>
            <select id="curso_id" name="curso_id" required>
                <option value="">Selecione um curso</option>
                <?php foreach ($data['cursos'] as $curso): ?>
                    <option value="<?php echo $curso['id']; ?>"><?php echo htmlspecialchars($curso['nome']); ?></option>
                <?php endforeach; ?>
            </select>
        </div>
        <div class="form-group">
            <label for="professor_id">Professor:</label>
            <select id="professor_id" name="professor_id" required>
                <option value="">Selecione um professor</option>
                <?php foreach ($data['professores'] as $professor): ?>
                    <option value="<?php echo $professor['id']; ?>"><?php echo htmlspecialchars($professor['nome']); ?></option>
                <?php endforeach; ?>
            </select>
        </div>
        <div class="form-group">
            <label for="horario">Horário:</label>
            <input type="text" id="horario" name="horario" placeholder="Ex: Segundas e Quartas, 18h-19h" required>
        </div>
        <div class="form-group">
            <label for="sala">Sala:</label>
            <input type="text" id="sala" name="sala" placeholder="Ex: Sala 05" required>
        </div>
        <div class="form-group">
            <label for="status">Status:</label>
            <select id="status" name="status" required>
                <option value="aberta">Aberta</option>
                <option value="completa">Completa</option>
                <option value="em_andamento">Em Andamento</option>
                <option value="concluida">Concluída</option>
            </select>
        </div>
        <button type="submit" class="btn">Salvar</button>
        <a href="<?php echo BASE_URL; ?>/index.php?url=turma" class="btn-secondary">Cancelar</a>
    </form>
</main>