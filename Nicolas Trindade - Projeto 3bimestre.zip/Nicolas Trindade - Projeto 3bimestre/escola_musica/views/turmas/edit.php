<main class="container">
    <h2>Editar Turma</h2>
    <form action="<?php echo BASE_URL; ?>/index.php?url=turma/update/<?php echo $data['turma']['id']; ?>" method="POST">
        <div class="form-group">
            <label for="curso_id">Curso:</label>
            <select id="curso_id" name="curso_id" required>
                <option value="">Selecione um curso</option>
                <?php foreach ($data['cursos'] as $curso): ?>
                    <option value="<?php echo $curso['id']; ?>" <?php echo ($data['turma']['curso_id'] == $curso['id']) ? 'selected' : ''; ?>>
                        <?php echo htmlspecialchars($curso['nome']); ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </div>
        <div class="form-group">
            <label for="professor_id">Professor:</label>
            <select id="professor_id" name="professor_id" required>
                <option value="">Selecione um professor</option>
                <?php foreach ($data['professores'] as $professor): ?>
                    <option value="<?php echo $professor['id']; ?>" <?php echo ($data['turma']['professor_id'] == $professor['id']) ? 'selected' : ''; ?>>
                        <?php echo htmlspecialchars($professor['nome']); ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </div>
        <div class="form-group">
            <label for="horario">Horário:</label>
            <input type="text" id="horario" name="horario" value="<?php echo htmlspecialchars($data['turma']['horario']); ?>" required>
        </div>
        <div class="form-group">
            <label for="sala">Sala:</label>
            <input type="text" id="sala" name="sala" value="<?php echo htmlspecialchars($data['turma']['sala']); ?>" required>
        </div>
        <div class="form-group">
            <label for="status">Status:</label>
            <select id="status" name="status" required>
                <option value="aberta" <?php echo ($data['turma']['status'] == 'aberta') ? 'selected' : ''; ?>>Aberta</option>
                <option value="completa" <?php echo ($data['turma']['status'] == 'completa') ? 'selected' : ''; ?>>Completa</option>
                <option value="em_andamento" <?php echo ($data['turma']['status'] == 'em_andamento') ? 'selected' : ''; ?>>Em Andamento</option>
                <option value="concluida" <?php echo ($data['turma']['status'] == 'concluida') ? 'selected' : ''; ?>>Concluída</option>
            </select>
        </div>
        <button type="submit" class="btn">Atualizar</button>
        <a href="<?php echo BASE_URL; ?>/index.php?url=turma" class="btn-secondary">Cancelar</a>
    </form>
</main>