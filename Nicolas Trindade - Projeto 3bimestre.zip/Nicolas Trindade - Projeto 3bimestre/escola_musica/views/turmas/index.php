<main class="container">
    <div class="main-header">
        <h2>Gestão de Turmas</h2>
        <a href="<?php echo BASE_URL; ?>/index.php?url=turma/create" class="btn">Nova Turma</a>
    </div>

    <table>
        <thead>
            <tr>
                <th>Curso</th>
                <th>Professor</th>
                <th>Horário</th>
                <th>Sala</th>
                <th>Status</th>
                <th>Ações</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($turmas as $turma): ?>
            <tr>
                <td><?php echo htmlspecialchars($turma['curso_nome']); ?></td>
                <td><?php echo htmlspecialchars($turma['professor_nome']); ?></td>
                <td><?php echo htmlspecialchars($turma['horario']); ?></td>
                <td><?php echo htmlspecialchars($turma['sala']); ?></td>
                <td><?php echo ucfirst(htmlspecialchars($turma['status'])); ?></td>
                <td class="actions">
                    <a href="<?php echo BASE_URL; ?>/index.php?url=turma/edit/<?php echo $turma['id']; ?>">Editar</a>
                    <a href="<?php echo BASE_URL; ?>/index.php?url=turma/delete/<?php echo $turma['id']; ?>" 
                       onclick="return confirm('Tem certeza que deseja excluir?');">
                       Excluir
                    </a>
                </td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</main>