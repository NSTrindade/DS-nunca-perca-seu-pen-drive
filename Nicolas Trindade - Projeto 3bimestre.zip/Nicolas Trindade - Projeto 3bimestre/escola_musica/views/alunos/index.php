<main class="container">
    <div class="main-header">
        <h2>Gestão de Alunos</h2>
        <a href="<?php echo BASE_URL; ?>/index.php?url=aluno/create" class="btn">Novo Aluno</a>
    </div>

    <table>
        <thead>
            <tr>
                <th>Nome</th>
                <th>Email</th>
                <th>Telefone</th>
                <th>Data de Nascimento</th>
                <th>Ações</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($alunos as $aluno): ?>
            <tr>
                <td><?php echo htmlspecialchars($aluno['nome']); ?></td>
                <td><?php echo htmlspecialchars($aluno['email']); ?></td>
                <td><?php echo htmlspecialchars($aluno['telefone']); ?></td>
                <td><?php echo date('d/m/Y', strtotime($aluno['data_nascimento'])); ?></td>
                <td class="actions">
                    <a href="<?php echo BASE_URL; ?>/index.php?url=aluno/edit/<?php echo $aluno['id']; ?>">Editar</a>
                    <a href="<?php echo BASE_URL; ?>/index.php?url=aluno/delete/<?php echo $aluno['id']; ?>" 
                       onclick="return confirm('Tem certeza que deseja excluir?');">
                       Excluir
                    </a>
                </td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</main>