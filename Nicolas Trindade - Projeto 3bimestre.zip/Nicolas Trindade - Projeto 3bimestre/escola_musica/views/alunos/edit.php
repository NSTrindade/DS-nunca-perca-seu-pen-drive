<main class="container">
    <h2>Editar Aluno</h2>
    <form action="<?php echo BASE_URL; ?>/index.php?url=aluno/update/<?php echo $aluno['id']; ?>" method="POST">
        <div class="form-group">
            <label for="nome">Nome:</label>
            <input type="text" id="nome" name="nome" value="<?php echo htmlspecialchars($aluno['nome']); ?>" required>
        </div>
        <div class="form-group">
            <label for="email">Email:</label>
            <input type="email" id="email" name="email" value="<?php echo htmlspecialchars($aluno['email']); ?>" required>
        </div>
        <div class="form-group">
            <label for="telefone">Telefone:</label>
            <input type="text" id="telefone" name="telefone" value="<?php echo htmlspecialchars($aluno['telefone']); ?>">
        </div>
        <div class="form-group">
            <label for="data_nascimento">Data de Nascimento:</label>
            <input type="date" id="data_nascimento" name="data_nascimento" value="<?php echo htmlspecialchars($aluno['data_nascimento']); ?>" required>
        </div>
        <button type="submit" class="btn">Atualizar</button>
        <a href="<?php echo BASE_URL; ?>/index.php?url=aluno" class="btn-secondary">Cancelar</a>
    </form>
</main>