<main class="container">
    <h2>Novo Professor</h2>
    <form action="<?php echo BASE_URL; ?>/index.php?url=professor/store" method="POST">
        <div class="form-group">
            <label for="nome">Nome:</label>
            <input type="text" id="nome" name="nome" required>
        </div>
        <div class="form-group">
            <label for="email">Email:</label>
            <input type="email" id="email" name="email" required>
        </div>
        <div class="form-group">
            <label for="telefone">Telefone:</label>
            <input type="text" id="telefone" name="telefone">
        </div>
        <button type="submit" class="btn">Salvar</button>
        <a href="<?php echo BASE_URL; ?>/index.php?url=professor" class="btn-secondary">Cancelar</a>
    </form>
</main>