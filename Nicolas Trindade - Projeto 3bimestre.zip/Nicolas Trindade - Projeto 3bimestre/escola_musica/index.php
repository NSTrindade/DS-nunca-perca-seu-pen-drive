<?php
session_start();

// Define a constante para o caminho raiz do projeto no servidor
define('BASE_PATH', __DIR__);
// Define a URL base do projeto (ajuste o nome da pasta se for diferente)
define('BASE_URL', '/escola_musica'); 

// Inclui o arquivo de configuração do banco de dados
require_once BASE_PATH . '/config/Database.php';

// Roteamento simples
$url = isset($_GET['url']) ? $_GET['url'] : 'home';
$url = explode('/', rtrim($url, '/'));

$controllerName = !empty($url[0]) ? ucfirst($url[0]) . 'Controller' : 'HomeController';
$methodName = isset($url[1]) ? $url[1] : 'index';
$params = array_slice($url, 2);

$controllerFile = BASE_PATH . '/controllers/' . $controllerName . '.php';

// Proteção de rotas
if ($controllerName != 'AuthController' && !isset($_SESSION['user_id'])) {
    header('Location: ' . BASE_URL . '/index.php?url=auth/login');
    exit();
}

if (file_exists($controllerFile)) {
    require_once $controllerFile;
    if (class_exists($controllerName)) {
        $controller = new $controllerName();
        if (method_exists($controller, $methodName)) {
            call_user_func_array([$controller, $methodName], $params);
        } else {
            die("Erro: Método '{$methodName}' não encontrado no controller '{$controllerName}'.");
        }
    } else {
        die("Erro: Classe '{$controllerName}' não encontrada no arquivo.");
    }
} else {
    // Redireciona para home se a página não existir e estiver logado
    if (isset($_SESSION['user_id'])) {
        header('Location: ' . BASE_URL . '/index.php?url=home');
    } else {
        die("Erro: Controller '{$controllerName}' não encontrado.");
    }
}