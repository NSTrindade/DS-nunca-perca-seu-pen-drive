<?php
require_once BASE_PATH . '/model/Aluno.php';

class AlunoController {
    private $db;
    private $alunoModel;

    public function __construct() {
        $this->db = (new Database())->connect();
        $this->alunoModel = new Aluno($this->db);
    }

    public function index() {
        $alunos = $this->alunoModel->getAll();
        require_once BASE_PATH . '/views/layouts/header.php';
        require_once BASE_PATH . '/views/alunos/index.php';
        require_once BASE_PATH . '/views/layouts/footer.php';
    }

    public function create() {
        require_once BASE_PATH . '/views/layouts/header.php';
        require_once BASE_PATH . '/views/alunos/create.php';
        require_once BASE_PATH . '/views/layouts/footer.php';
    }

    public function store() {
        if ($_SERVER['REQUEST_METHOD'] == 'POST') {
            $dados = [
                'nome' => $_POST['nome'],
                'email' => $_POST['email'],
                'telefone' => $_POST['telefone'],
                'data_nascimento' => $_POST['data_nascimento']
            ];
            if ($this->alunoModel->create($dados)) {
                header('Location: ' . BASE_URL . '/index.php?url=aluno');
            }
        }
    }

    public function edit($id) {
        $aluno = $this->alunoModel->getById($id);
        require_once BASE_PATH . '/views/layouts/header.php';
        require_once BASE_PATH . '/views/alunos/edit.php';
        require_once BASE_PATH . '/views/layouts/footer.php';
    }

    public function update($id) {
        if ($_SERVER['REQUEST_METHOD'] == 'POST') {
            $dados = [
                'id' => $id,
                'nome' => $_POST['nome'],
                'email' => $_POST['email'],
                'telefone' => $_POST['telefone'],
                'data_nascimento' => $_POST['data_nascimento']
            ];
            if ($this->alunoModel->update($dados)) {
                header('Location: ' . BASE_URL . '/index.php?url=aluno');
            }
        }
    }

    public function delete($id) {
        if ($this->alunoModel->delete($id)) {
            header('Location: ' . BASE_URL . '/index.php?url=aluno');
        }
    }
}