<?php
require_once BASE_PATH . '/model/Professor.php';

class ProfessorController {
    private $db;
    private $professorModel;

    public function __construct() {
        $this->db = (new Database())->connect();
        $this->professorModel = new Professor($this->db);
    }

    public function index() {
        $professores = $this->professorModel->getAll();
        require_once BASE_PATH . '/views/layouts/header.php';
        require_once BASE_PATH . '/views/professores/index.php';
        require_once BASE_PATH . '/views/layouts/footer.php';
    }

    public function create() {
        require_once BASE_PATH . '/views/layouts/header.php';
        require_once BASE_PATH . '/views/professores/create.php';
        require_once BASE_PATH . '/views/layouts/footer.php';
    }

    public function store() {
        if ($_SERVER['REQUEST_METHOD'] == 'POST') {
            $dados = [ 'nome' => $_POST['nome'], 'email' => $_POST['email'], 'telefone' => $_POST['telefone'] ];
            if ($this->professorModel->create($dados)) {
                // Redirect atualizado
                header('Location: ' . BASE_URL . '/index.php?url=professor');
            }
        }
    }

    public function edit($id) {
        $professor = $this->professorModel->getById($id);
        require_once BASE_PATH . '/views/layouts/header.php';
        require_once BASE_PATH . '/views/professores/edit.php';
        require_once BASE_PATH . '/views/layouts/footer.php';
    }

    public function update($id) {
        if ($_SERVER['REQUEST_METHOD'] == 'POST') {
            $dados = [ 'id' => $id, 'nome' => $_POST['nome'], 'email' => $_POST['email'], 'telefone' => $_POST['telefone'] ];
            if ($this->professorModel->update($dados)) {
                // Redirect atualizado
                header('Location: ' . BASE_URL . '/index.php?url=professor');
            }
        }
    }

    public function delete($id) {
        if ($this->professorModel->delete($id)) {
            // Redirect atualizado
            header('Location: ' . BASE_URL . '/index.php?url=professor');
        }
    }
}