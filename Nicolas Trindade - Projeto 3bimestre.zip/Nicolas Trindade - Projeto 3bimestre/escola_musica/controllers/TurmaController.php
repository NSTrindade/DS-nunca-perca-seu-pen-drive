<?php
require_once BASE_PATH . '/model/Turma.php';
require_once BASE_PATH . '/model/Curso.php';
require_once BASE_PATH . '/model/Professor.php';

class TurmaController {
    private $db;
    private $turmaModel;
    private $cursoModel;
    private $professorModel;

    public function __construct() {
        $this->db = (new Database())->connect();
        $this->turmaModel = new Turma($this->db);
        $this->cursoModel = new Curso($this->db);
        $this->professorModel = new Professor($this->db);
    }

    public function index() {
        $turmas = $this->turmaModel->getAll();
        require_once BASE_PATH . '/views/layouts/header.php';
        require_once BASE_PATH . '/views/turmas/index.php';
        require_once BASE_PATH . '/views/layouts/footer.php';
    }

    private function getCursosEProfessores() {
        $cursos = $this->cursoModel->getAll();
        $professores = $this->professorModel->getAll();
        return ['cursos' => $cursos, 'professores' => $professores];
    }
    
    public function create() {
        $data = $this->getCursosEProfessores();
        require_once BASE_PATH . '/views/layouts/header.php';
        require_once BASE_PATH . '/views/turmas/create.php';
        require_once BASE_PATH . '/views/layouts/footer.php';
    }

    public function store() {
        if ($_SERVER['REQUEST_METHOD'] == 'POST') {
            $dados = [
                'curso_id' => $_POST['curso_id'],
                'professor_id' => $_POST['professor_id'],
                'horario' => $_POST['horario'],
                'sala' => $_POST['sala'],
                'status' => $_POST['status']
            ];
            if ($this->turmaModel->create($dados)) {
                header('Location: ' . BASE_URL . '/index.php?url=turma');
            }
        }
    }

    public function edit($id) {
        $data = $this->getCursosEProfessores();
        $data['turma'] = $this->turmaModel->getById($id);

        require_once BASE_PATH . '/views/layouts/header.php';
        require_once BASE_PATH . '/views/turmas/edit.php';
        require_once BASE_PATH . '/views/layouts/footer.php';
    }

    public function update($id) {
        if ($_SERVER['REQUEST_METHOD'] == 'POST') {
            $dados = [
                'id' => $id,
                'curso_id' => $_POST['curso_id'],
                'professor_id' => $_POST['professor_id'],
                'horario' => $_POST['horario'],
                'sala' => $_POST['sala'],
                'status' => $_POST['status']
            ];
            if ($this->turmaModel->update($dados)) {
                header('Location: ' . BASE_URL . '/index.php?url=turma');
            }
        }
    }

    public function delete($id) {
        if ($this->turmaModel->delete($id)) {
            header('Location: ' . BASE_URL . '/index.php?url=turma');
        }
    }
}