<?php
// Adiciona o require_once que estava faltando para carregar a classe Usuario
require_once BASE_PATH . '/model/Usuario.php';

class AuthController {

    public function login() {
        require_once BASE_PATH . '/views/auth/login.php';
    }

    public function process_login() {
        if ($_SERVER['REQUEST_METHOD'] == 'POST') {
            $email = $_POST['email'] ?? '';
            $senha = $_POST['senha'] ?? '';

            $db = (new Database())->connect();
            $usuarioModel = new Usuario($db);
            $user = $usuarioModel->login($email, $senha);

            if ($user) {
                // Correção do bug que eu havia cometido antes (a['id'] virou $user['id'])
                $_SESSION['user_id'] = $user['id'];
                $_SESSION['user_nome'] = $user['nome'];
                
                header('Location: ' . BASE_URL . '/index.php?url=home');
                exit();
            } else {
                $error = "Email ou senha inválidos.";
                require_once BASE_PATH . '/views/auth/login.php';
            }
        }
    }

    public function logout() {
        session_unset();
        session_destroy();
        header('Location: ' . BASE_URL . '/index.php?url=auth/login');
        exit();
    }
}