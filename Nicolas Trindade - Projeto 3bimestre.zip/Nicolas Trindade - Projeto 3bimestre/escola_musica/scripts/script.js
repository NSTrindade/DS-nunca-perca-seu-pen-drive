// Aguarda o carregamento completo do DOM
document.addEventListener('DOMContentLoaded', function() {
    
    console.log("Sistema da Escola de Música iniciado.");

    // Função simples para validar email
    function validateEmail(email) {
        const re = /^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
        return re.test(String(email).toLowerCase());
    }

    // Validação de exemplo para formulários com campo de email
    const forms = document.querySelectorAll('form');
    forms.forEach(form => {
        form.addEventListener('submit', function(event) {
            const emailInput = form.querySelector('input[type="email"]');
            if (emailInput && !validateEmail(emailInput.value)) {
                alert('Por favor, insira um endereço de e-mail válido.');
                event.preventDefault(); // Impede o envio do formulário
            }
        });
    });
});