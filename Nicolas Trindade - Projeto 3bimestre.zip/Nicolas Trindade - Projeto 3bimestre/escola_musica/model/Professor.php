<?php
class Professor {
    private $conn;
    private $table = 'professores';

    public function __construct($db) {
        $this->conn = $db;
    }

    public function getAll() {
        $query = 'SELECT * FROM ' . $this->table . ' ORDER BY nome';
        $stmt = $this->conn->prepare($query);
        $stmt->execute();
        return $stmt->fetchAll();
    }

    public function getById($id) {
        $query = 'SELECT * FROM ' . $this->table . ' WHERE id = :id';
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':id', $id);
        $stmt->execute();
        return $stmt->fetch();
    }

    public function create($dados) {
        $query = 'INSERT INTO ' . $this->table . ' (nome, email, telefone) VALUES (:nome, :email, :telefone)';
        $stmt = $this->conn->prepare($query);
        
        $stmt->bindParam(':nome', htmlspecialchars(strip_tags($dados['nome'])));
        $stmt->bindParam(':email', htmlspecialchars(strip_tags($dados['email'])));
        $stmt->bindParam(':telefone', htmlspecialchars(strip_tags($dados['telefone'])));
        
        return $stmt->execute();
    }

    public function update($dados) {
        $query = 'UPDATE ' . $this->table . ' SET nome = :nome, email = :email, telefone = :telefone WHERE id = :id';
        $stmt = $this->conn->prepare($query);
        
        $stmt->bindParam(':id', $dados['id']);
        $stmt->bindParam(':nome', htmlspecialchars(strip_tags($dados['nome'])));
        $stmt->bindParam(':email', htmlspecialchars(strip_tags($dados['email'])));
        $stmt->bindParam(':telefone', htmlspecialchars(strip_tags($dados['telefone'])));
        
        return $stmt->execute();
    }

    public function delete($id) {
        $query = 'DELETE FROM ' . $this->table . ' WHERE id = :id';
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':id', $id);
        return $stmt->execute();
    }
}