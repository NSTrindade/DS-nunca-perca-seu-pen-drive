<?php
class Curso {
    private $conn;
    private $table = 'cursos';

    public function __construct($db) {
        $this->conn = $db;
    }

    // Pega todos os cursos para preencher um menu <select>
    public function getAll() {
        $query = 'SELECT id, nome FROM ' . $this->table . ' ORDER BY nome';
        $stmt = $this->conn->prepare($query);
        $stmt->execute();
        return $stmt->fetchAll();
    }
}