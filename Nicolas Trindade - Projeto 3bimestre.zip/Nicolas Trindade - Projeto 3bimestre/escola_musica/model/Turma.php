<?php
class Turma {
    private $conn;
    private $table = 'turmas';

    public function __construct($db) {
        $this->conn = $db;
    }

    // Usamos JOIN para pegar os nomes do curso e do professor
    public function getAll() {
        $query = 'SELECT t.id, t.horario, t.sala, t.status, c.nome as curso_nome, p.nome as professor_nome
                  FROM ' . $this->table . ' t
                  LEFT JOIN cursos c ON t.curso_id = c.id
                  LEFT JOIN professores p ON t.professor_id = p.id
                  ORDER BY c.nome, t.horario';
        $stmt = $this->conn->prepare($query);
        $stmt->execute();
        return $stmt->fetchAll();
    }
    
    public function getById($id) {
        $query = 'SELECT * FROM ' . $this->table . ' WHERE id = :id';
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':id', $id);
        $stmt->execute();
        return $stmt->fetch();
    }

    public function create($dados) {
        $query = 'INSERT INTO ' . $this->table . ' (curso_id, professor_id, horario, sala, status) VALUES (:curso_id, :professor_id, :horario, :sala, :status)';
        $stmt = $this->conn->prepare($query);

        $stmt->bindParam(':curso_id', $dados['curso_id']);
        $stmt->bindParam(':professor_id', $dados['professor_id']);
        $stmt->bindParam(':horario', htmlspecialchars(strip_tags($dados['horario'])));
        $stmt->bindParam(':sala', htmlspecialchars(strip_tags($dados['sala'])));
        $stmt->bindParam(':status', htmlspecialchars(strip_tags($dados['status'])));
        
        return $stmt->execute();
    }

    public function update($dados) {
        $query = 'UPDATE ' . $this->table . ' SET curso_id = :curso_id, professor_id = :professor_id, horario = :horario, sala = :sala, status = :status WHERE id = :id';
        $stmt = $this->conn->prepare($query);

        $stmt->bindParam(':id', $dados['id']);
        $stmt->bindParam(':curso_id', $dados['curso_id']);
        $stmt->bindParam(':professor_id', $dados['professor_id']);
        $stmt->bindParam(':horario', htmlspecialchars(strip_tags($dados['horario'])));
        $stmt->bindParam(':sala', htmlspecialchars(strip_tags($dados['sala'])));
        $stmt->bindParam(':status', htmlspecialchars(strip_tags($dados['status'])));
        
        return $stmt->execute();
    }

    public function delete($id) {
        $query = 'DELETE FROM ' . $this->table . ' WHERE id = :id';
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':id', $id);
        return $stmt->execute();
    }
}