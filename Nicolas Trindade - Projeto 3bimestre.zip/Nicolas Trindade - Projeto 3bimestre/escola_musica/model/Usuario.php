<?php
class Usuario {
    private $conn;
    private $table = 'usuarios';

    public function __construct($db) {
        $this->conn = $db;
    }

    public function login($email, $senha) {
        $query = 'SELECT id, nome, email, senha FROM ' . $this->table . ' WHERE email = :email LIMIT 1';
        
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':email', $email);
        $stmt->execute();

        // --- LÓGICA CORRIGIDA E MAIS ROBUSTA ---
        // 1. Tenta buscar o usuário
        $user = $stmt->fetch(PDO::FETCH_ASSOC);

        // 2. Se um usuário foi encontrado E a senha bate, retorna os dados do usuário
        if ($user && password_verify($senha, $user['senha'])) {
            return $user;
        }

        // 3. Se não, retorna falso
        return false;
    }
}