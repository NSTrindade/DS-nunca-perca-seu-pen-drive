<?php
// --- INFORMAÇÕES DE CONEXÃO ---
// Estas são as mesmas informações do seu arquivo config/Database.php
$host = 'localhost';
$db_name = 'escola_musica_db';
$username = 'root';
$password = ''; // Senha vazia para o padrão XAMPP
$email_para_buscar = 'admin@escola.com';

// ------------------------------------------------------------------

echo "<h1>Teste de Conexão Direta com o Banco de Dados</h1>";
echo "<p><strong>Horário do teste:</strong> " . date('Y-m-d H:i:s') . "</p>";
echo "<hr>";
echo "<p>Tentando conectar ao banco de dados: '{$db_name}' no host '{$host}'...</p>";

try {
    // 1. Tenta criar a conexão PDO
    $conn = new PDO("mysql:host={$host};dbname={$db_name};charset=utf8mb4", $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    echo "<p style='color:green; font-weight:bold;'>SUCESSO! A conexão com o banco de dados foi estabelecida.</p>";
    echo "<hr>";

    // 2. Tenta buscar o usuário
    echo "<h2>Buscando pelo usuário com o email: '{$email_para_buscar}'</h2>";
    $query = "SELECT * FROM usuarios WHERE email = :email";
    $stmt = $conn->prepare($query);
    $stmt->bindParam(':email', $email_para_buscar);
    $stmt->execute();

    // 3. Pega o resultado
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    // 4. Mostra o resultado
    echo "<h3>Resultado da busca (var_dump):</h3>";
    echo "<pre style='background-color:#f0f0f0; padding:10px; border:1px solid #ccc;'>";
    var_dump($user);
    echo "</pre>";

    if ($user) {
        echo "<p style='color:green; font-weight:bold;'>ÓTIMO! O usuário foi encontrado pelo PHP.</p>";
    } else {
        echo "<p style='color:red; font-weight:bold;'>PROBLEMA CONFIRMADO! O usuário NÃO foi encontrado pelo PHP.</p>";
        echo "<p>Isso prova que o ambiente PHP do seu XAMPP não está lendo os mesmos dados que o seu phpMyAdmin. A causa mais provável é ter múltiplas instalações de MySQL/MariaDB na sua máquina.</p>";
    }

} catch (PDOException $e) {
    echo "<p style='color:red; font-weight:bold;'>FALHA NA CONEXÃO!</p>";
    echo "<p>Mensagem de Erro: " . $e->getMessage() . "</p>";
}
?>