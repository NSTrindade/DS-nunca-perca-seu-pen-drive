

--- Quartz Icon Pack ---


Designer: Andy Gongea
Website: http://www.graphicrating.com/
Twitter: @andygongea





The icons are free to use for any personal or commercial projects.
Cheers!


I am looking for new projects on web design, graphic design and web development.
So feel free to contact me for any projects or collaborations.

http://www.graphicrating.com/