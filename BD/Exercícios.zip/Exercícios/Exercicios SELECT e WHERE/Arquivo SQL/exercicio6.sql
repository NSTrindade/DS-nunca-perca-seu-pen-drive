create database Exercicios;
use Exercicios;
show tables;
 CREATE TABLE clientes (
    id SERIAL PRIMARY KEY,
    nome VARCHAR(100),
    email VARCHAR(100),
    cidade VARCHAR(100)
 );
 INSERT INTO clientes (nome, email, cidade) VALUES
 ('Carlos Silva', 'carlos@email.com', 'São Paulo'),
 ('Ana Souza', 'ana@email.com', 'Rio de Janeiro'),
 ('Bruno Mendes', 'bruno@email.com', 'Belo Horizonte'),
 ('Mariana Lima', 'mariana@email.com', 'São Paulo');
select * from clientes where cidade="São Paulo";
 