create database Exercicios;
use Exercicios;
show tables;
CREATE TABLE produtos (
    id SERIAL PRIMARY KEY,
    nome VARCHAR(100),
    preco DECIMAL(10,2)
 );
 INSERT INTO produtos (nome, preco) VALUES
 ('Notebook', 3500.00),
 ('Smartphone', 2500.00),
 ('Tablet', 1500.00),
 ('Fone de Ouvido', 200.00);
 select * from produtos where preco > 1000;
 