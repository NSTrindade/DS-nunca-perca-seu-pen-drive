create database Exercicios;
use Exercicios;
CREATE TABLE pedidos (
    id SERIAL PRIMARY KEY,
    cliente_id INT,
    data_pedido DATE,
    valor_total DECIMAL(10,2)
 );
 INSERT INTO pedidos (cliente_id, data_pedido, valor_total) VALUES
 (1, '2024-02-15', 500.00),
 (2, '2024-02-18', 1500.00),
 (3, '2024-02-18', 1200.00),
 (4, '2024-02-10', 800.00);
 select * from pedidos where data_pedido =  '2024-02-18';
 