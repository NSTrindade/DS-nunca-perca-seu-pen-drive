create database Exercicios;
use Exercicios;

CREATE TABLE funcionarios (
    id SERIAL PRIMARY KEY,
    nome VARCHAR(100),
    cargo VARCHAR(50),
    salario DECIMAL(10,2)
 );
 INSERT INTO funcionarios (nome, cargo, salario) VALUES
 ('João Pedro', 'Gerente', 7500.00),
 ('Larissa Martins', 'Desenvolvedor', 5500.00),
 ('Fernando Costa', 'Designer', 4800.00),
 ('Clara Oliveira', 'Analista', 4000.00);
 
select * from funcionarios where salario between 4000.00 and 6000.00;
 