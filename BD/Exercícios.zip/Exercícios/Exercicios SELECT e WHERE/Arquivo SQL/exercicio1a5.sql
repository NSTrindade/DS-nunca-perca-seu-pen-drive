create database Exercicios;
use Exercicios;
create table Funcionarios (
id int auto_increment primary key,
nome varchar(100),
 email varchar(100),
 matricula int, 
 tempoDeCasa int, 
 sexo varchar(50),
 setor varchar(50)
 );
 insert into Funcionarios (nome, email, matricula, tempoDeCasa, sexo, setor) values
 ('Murilo','ea@gmail.com', 123, 17, 'Masculino', 'DS'),
 ('Pedro','aa@gmail.com', 223, 4, 'Masculino', 'DS'),
 ('Murilo','wa@gmail.com', 122, 16, 'Masculino', 'ADM'),
 ('Ana','ia@gmail.com', 113, 3, 'Feminino', 'RH'),
 ('Elena','eaw@gmail.com', 133, 5, 'Feminino', 'RH');
show tables;
select * from Funcionarios where sexo="Masculino";
select * from Funcionarios where sexo="Feminino";
select * from Funcionarios where tempoDeCasa > 15;
 