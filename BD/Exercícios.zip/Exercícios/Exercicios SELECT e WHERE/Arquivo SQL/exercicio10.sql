create database Exercicios;
use Exercicios;

CREATE TABLE produtos (
    id SERIAL PRIMARY KEY,
    nome VARCHAR(100),
    preco DECIMAL(10,2)
 );
 INSERT INTO produtos (nome, preco) VALUES
 ('Smartphone', 2500.00),
 ('Notebook', 3500.00),
 ('Tablet', 1500.00),
 ('Fone de Ouvido', 200.00),
 ('Smartwatch', 1800.00),
 ('Samsung TV', 4000.00),
 ('Câmera Digital', 2200.00),
 ('Suporte para Monitor', 300.00);
  select * from produtos where nome like 'S%';