package com.example.greetingcard

// Importações necessárias
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import com.example.greetingcard.ui.theme.GreetingCardTheme

// Classe principal da atividade
class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            // Aplica o tema customizado
            GreetingCardTheme {
                // Cria uma área de fundo com a cor do tema
                Surface(
                    modifier = Modifier.fillMaxSize(), // Ocupa toda a tela
                    color = MaterialTheme.colorScheme.background // Cor de fundo do tema
                ) {
                    Greeting("Meghan") // Chama a função que exibe a saudação
                }
            }
        }
    }
}

// Função composable que mostra uma mensagem de saudação
@Composable
fun Greeting(name: String, modifier: Modifier = Modifier) {
    // Cria um fundo colorido
    Surface(color = Color.Cyan) {
        // Texto com padding (espaçamento interno)
        Text(
            text = "Hi, my name is $name!", // Mensagem com o nome
            modifier = modifier.padding(24.dp) // Espaçamento ao redor do texto
        )
    }
}

// Pré-visualização do componente Greeting no Android Studio
@Preview(showBackground = true)
@Composable
fun GreetingPreview() {
    GreetingCardTheme {
        Greeting("Meghan") // Mostra a saudação na prévia
    }
}
