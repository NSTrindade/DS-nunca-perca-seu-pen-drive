package ordenacaosimples;

// Importa a classe Arrays para utilizar o método toString() na exibição do vetor
import java.util.Arrays;

// Define a classe principal
public class OrdenacaoSimples {
    // Método principal que será executado
    public static void main(String[] args) {
        // Declara e inicializa o vetor com os números fornecidos
        int[] numeros = {9, 1, 3, 4, 2, 0, 8, 5, 7, 6};
        
        // Cria uma cópia do vetor original para preservar os valores iniciais
        int[] original = numeros.clone();
        
        // Ordenação crescente manual
        // Variável para contar o número de varreduras (passagens)
        int passagensCrescente = 0;
        // Cria uma cópia do vetor original para ordenação crescente
        int[] crescente = original.clone();
        // Loop externo: percorre cada elemento do vetor
        for (int i = 0; i < crescente.length; i++) {
            // Loop interno: compara o elemento atual com os subsequentes
            for (int j = i + 1; j < crescente.length; j++) {
                // Verifica se o elemento atual é maior que o próximo (necessita troca)
                if (crescente[i] > crescente[j]) {
                    // Realiza a troca dos elementos
                    int temp = crescente[i];
                    crescente[i] = crescente[j];
                    crescente[j] = temp;
                }
            }
            // Incrementa o contador de passagens após cada iteração do loop externo
            passagensCrescente++;
        }
        
        // Ordenação decrescente manual
        // Variável para contar o número de varreduras (passagens)
        int passagensDecrescente = 0;
        // Cria uma cópia do vetor original para ordenação decrescente
        int[] decrescente = original.clone();
        // Loop externo: percorre cada elemento do vetor
        for (int i = 0; i < decrescente.length; i++) {
            // Loop interno: compara o elemento atual com os subsequentes
            for (int j = i + 1; j < decrescente.length; j++) {
                // Verifica se o elemento atual é menor que o próximo (necessita troca)
                if (decrescente[i] < decrescente[j]) {
                    // Realiza a troca dos elementos
                    int temp = decrescente[i];
                    decrescente[i] = decrescente[j];
                    decrescente[j] = temp;
                }
            }
            // Incrementa o contador de passagens após cada iteração do loop externo
            passagensDecrescente++;
        }
        
        // Exibe o vetor original
        System.out.println("Original: " + Arrays.toString(original));
        // Exibe o vetor ordenado em ordem crescente
        System.out.println("\nOrdem Crescente: " + Arrays.toString(crescente));
        // Exibe a quantidade de passagens realizadas para ordenação crescente
        System.out.println("Passagens Crescente: " + passagensCrescente);
        
        // Exibe o vetor ordenado em ordem decrescente
        System.out.println("\nOrdem Decrescente: " + Arrays.toString(decrescente));
        // Exibe a quantidade de passagens realizadas para ordenação decrescente
        System.out.println("Passagens Decrescente: " + passagensDecrescente);
    }
}