package exo;

import javax.swing.*;

public class ExO {
    public static void main(String[] args) {
        O app = new O(); 
        app.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); 
    }
    
}
