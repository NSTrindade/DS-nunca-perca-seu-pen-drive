package exo;

import javax.swing.*; 
import java.awt.*; 
import java.awt.event.*;  

public class O extends JFrame{
  
//Criando as váriaveis
JLabel rotulo1, rotulo2, exibir; 
JTextField texto1,texto2; 
JButton somar, sub, div, mul; 

//Método construtor
public O(){ 

super("Exemplo de soma"); 
Container tela = getContentPane(); 
setLayout(null); 
tela.setBackground(Color.white);

//Instancia dos rotulos
rotulo1 = new JLabel("1° Número "); 
rotulo2 = new JLabel("2° Número "); 

//Faz a formatação dos rotulos
rotulo1.setFont(new Font("Arial", Font.BOLD, 16));
rotulo2.setFont(new Font("Arial", Font.BOLD, 16));

//Instancia dos campos de texto
texto1 = new JTextField(5); 
texto2 = new JTextField(5);

//Instancia da inicialização da mansagem de exibição das contas
exibir = new JLabel(""); 

//Instancia dos botões de operação
somar = new JButton("Somar"); 
sub =  new JButton("Subtrair");
div =  new JButton("Dividir");
mul = new JButton("Multiplicar");

//Posiciona os elementos de texto na tela
rotulo1.setBounds(35,20,100,20); rotulo2.setBounds(35,60,100,20); 
texto1.setBounds(120,20,200,20); texto2.setBounds(120,60,200,20); 
exibir.setBounds(130,150,200,20); 

//Faz a formatação da mansagem de exibição das contas
exibir.setFont(new Font("Arial", Font.BOLD, 20));

//Posiciona os botões na tela
somar.setBounds(100,100,80,20);
sub.setBounds(10,100,80,20);
div.setBounds(190,100,80,20);
mul.setBounds(280,100,100,20);

//Define as cores dos botões
somar.setBackground(Color.gray);
sub.setBackground(Color.gray);
div.setBackground(Color.gray);
mul.setBackground(Color.gray);
somar.setForeground(Color.white);
sub.setForeground(Color.white);
div.setForeground(Color.white);
mul.setForeground(Color.white);

//Adiciona um função de soma ao clicar no botão
somar.addActionListener( 
new ActionListener(){ 
public void actionPerformed(ActionEvent e){ 
int numero1, numero2, soma; 
soma=0; 
numero1 = Integer.parseInt(texto1.getText()); 
numero2 = Integer.parseInt(texto2.getText()); 
soma = numero1 + numero2; 
exibir.setVisible(true); 
exibir.setText(numero1 + " + " + numero2 + " = " + soma); 
} 
} 
); 

//Adiciona um função de subtração ao clicar no botão
sub.addActionListener( 
new ActionListener(){ 
public void actionPerformed(ActionEvent e){ 
int numero1, numero2, su; 
su=0; 
numero1 = Integer.parseInt(texto1.getText()); 
numero2 = Integer.parseInt(texto2.getText()); 
su = numero1 - numero2; 
exibir.setVisible(true); 
exibir.setText(numero1 + " - " + numero2 + " = "+su); 
} 
} 
);

//Adiciona um função de divisão ao clicar no botão
div.addActionListener( 
new ActionListener(){ 
public void actionPerformed(ActionEvent e){ 
double numero1, numero2, di; 
di=0; 
numero1 = Double.parseDouble(texto1.getText()); 
numero2 = Double.parseDouble(texto2.getText()); 
di = numero1 / numero2; 
exibir.setVisible(true); 
exibir.setText(numero1 + " : " + numero2 + " = "+di); 
if (numero2 == 0){
    exibir.setFont(new Font("Arial", Font.BOLD, 16));
    exibir.setBounds(50,150,400,20); 
    exibir.setText(" Não é possível dividir por zero. "); 
}
} 
} 
);

//Adiciona um função de multiplicação ao clicar no botão
mul.addActionListener( 
new ActionListener(){ 
public void actionPerformed(ActionEvent e){ 
int numero1, numero2, mu; 
mu=0; 
numero1 = Integer.parseInt(texto1.getText()); 
numero2 = Integer.parseInt(texto2.getText()); 
mu = numero1 * numero2; 
exibir.setVisible(true); 
exibir.setText(numero1 + " x " + numero2 + " = "+mu); 
} 
} 
);

//Inicia como falso para não mostrar na tela quando não clica no botão
exibir.setVisible(false); 

//Adicona os elemnetos na tela
tela.add(rotulo1); tela.add(rotulo2);
tela.add(texto1); tela.add(texto2); 
tela.add(exibir);
tela.add(somar); tela.add(sub);tela.add(div);tela.add(mul);

//Define as formatações e configurações da tela
setSize(400, 250);
setResizable(false);
setLocationRelativeTo(null);
setVisible(true); 
} 
}
