package hipotenusa;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.lang.Math;

public class HipotenusaForm extends JFrame {

    //Inicializando as variaveis de instancia
    public JTextField txtCatetoA, txtCatetoB, txtHipotenusa;
    public JButton btnCalcular;
    public JLabel lblTitulo, lblCatetoA, lblCatetoB, lblHipotenusa, lblImagem;
    public JTextField txtHipotenusaResultado = new JTextField();

    public HipotenusaForm() {
        //Definindo os parametros da janela
        super("Calculadora de Hipotenusa");
        setSize(525, 350);
        setLocationRelativeTo(null);

        //Iniciando a variavel que vai pegar as propriedades da tela
        Container tela = getContentPane();
        tela.setLayout(null);

        // Cabeçalho
        lblTitulo = new JLabel("Calculadora de Hipotenusa");
        lblTitulo.setFont(new Font("Arial", Font.BOLD, 20));
        lblTitulo.setBounds(130, 20, 300, 30);
        tela.add(lblTitulo);

        // Imagem do triângulo retângulo e fórmula
        ImageIcon imagemIcon = new ImageIcon("h.png");
        lblImagem = new JLabel(imagemIcon);
        lblImagem.setBounds(280, 60, imagemIcon.getIconWidth(), imagemIcon.getIconHeight());
        tela.add(lblImagem);

        // Labels e TextFields para cateto A
        lblCatetoA = new JLabel("Cateto A:");
        lblCatetoA.setBounds(30, 70, 80, 25);
        tela.add(lblCatetoA);
        txtCatetoA = new JTextField();
        txtCatetoA.setBounds(120, 70, 150, 25);
        tela.add(txtCatetoA);

        // Labels e TextFields para cateto B
        lblCatetoB = new JLabel("Cateto B:");
        lblCatetoB.setBounds(30, 110, 80, 25);
        tela.add(lblCatetoB);
        txtCatetoB = new JTextField();
        txtCatetoB.setBounds(120, 110, 150, 25);
        tela.add(txtCatetoB);

        // Botão Calcular
        btnCalcular = new JButton("Calcular");
        btnCalcular.setBounds(120, 150, 150, 30);
        btnCalcular.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                double catetoA = Double.parseDouble(txtCatetoA.getText());
                double catetoB = Double.parseDouble(txtCatetoB.getText());

                double hipotenusa = Math.sqrt(Math.pow(catetoA, 2) + Math.pow(catetoB, 2));
                txtHipotenusaResultado.setText("" + hipotenusa);
            }
        });
        tela.add(btnCalcular);

        // Resultado Hipotenusa
        lblHipotenusa = new JLabel("Hipotenusa:");
        lblHipotenusa.setBounds(30, 210, 90, 25);
        tela.add(lblHipotenusa);
        txtHipotenusaResultado.setBounds(120, 210, 150, 25);
        txtHipotenusaResultado.setEditable(false);
        tela.add(txtHipotenusaResultado);
        
        //Deixando visivel na tela
        setVisible(true);
    }

}
