package hipotenusa;

import javax.swing.*;

public class Hipotenusa {

    public static void main(String[] args) {
        HipotenusaForm app = new HipotenusaForm();
        app.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }
    
}
