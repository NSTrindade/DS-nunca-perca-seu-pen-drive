import javax.swing.*;
public class Pessoa {
     String nome;
     String idade;
     
     //construtor
     public void Pessoa(String nome, String idade) {
         this.nome = nome;
         this.idade = idade;
     }
     
     
        //métodos
         public void definirNome() {
             nome = JOptionPane.showInputDialog(null, "Digite nome do professor:");
         }
         public void retornarNome() {
             
         }
         
         public void definirIdade() {
             idade = JOptionPane.showInputDialog(null, "Digite idade do professor:");
         }
         
         public void retornarIdade() {
             
         }
         
         
     }
