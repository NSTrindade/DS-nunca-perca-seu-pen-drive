import javax.swing.*;
public class Aluno extends Pessoa {
      String curso;
      
      public void definirCurso() {
          curso = JOptionPane.showInputDialog(null, "Digite curso do aluno:");
      }
      public void retornarCurso() {
          
      }
    }

