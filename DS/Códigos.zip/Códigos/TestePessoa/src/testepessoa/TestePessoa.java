import javax.swing.JOptionPane;

public class TestePessoa {

    public static void main(String[] args) {
        Pessoa pes = new Pessoa();
        
        int funcao = Integer.parseInt(JOptionPane.showInputDialog(null, "Digite a função: \n 1-Professor\nQualquer numero-Aluno"));
       
        if (funcao == 1) {
        Professor prof = new Professor();
        pes.definirNome();
        pes.definirIdade();
        prof.definirFormacao();
        JOptionPane.showMessageDialog(null, "Nome do professor: " + pes.nome + "\nIdade do professor: " + pes.idade + "\nFormacao do professor: " + prof.formacao);
        } else {
        Aluno alu = new Aluno();
        pes.definirNome();
        pes.definirIdade();
        alu.definirCurso();
        JOptionPane.showMessageDialog(null, "Nome do aluno: " + pes.nome + "\nIdade do aluno: " + pes.idade + "\nCurso do aluno: " + alu.curso);
        }
        
    }
    
}
