import javax.swing.*;

public class Professor extends Pessoa{
    String formacao;
    
    public void definirFormacao() {
        formacao = JOptionPane.showInputDialog(null, "Digite formacao do professor:");
    }   
    public void retornarFormacao() {
    
    }
}
