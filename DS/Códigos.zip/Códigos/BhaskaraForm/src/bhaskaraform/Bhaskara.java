/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package bhaskaraform;

/**
 *
 * @author space
 */
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.lang.Math;

public class Bhaskara extends JFrame {
    
    //Inicializando as variaveis de instancia
     JTextField txtA, txtB, txtC, txtDelta;
     JButton btnCalcular;
     JLabel lblFormula, lblTitulo, lblA, lblB, lblC, lblDelta, lblX1, lblX2;
     JTextField txtX1 = new JTextField();
     JTextField txtX2 = new JTextField();

    public Bhaskara() {
        //Definindo os parametros da janela
        super("Fórmula de Bhaskara");
        setSize(650, 500);
        setLocationRelativeTo(null);

        //Iniciando a variavel que vai pegar as propriedades da tela
        Container tela = getContentPane();
        tela.setLayout(null);

        // Cabeçalho
        lblTitulo = new JLabel("Fórmula de Bhaskara");
        lblTitulo.setFont(new Font("Arial", Font.BOLD, 20));
        lblTitulo.setHorizontalAlignment(SwingConstants.CENTER);
        lblTitulo.setBounds(150, 20, 300, 30); 
        tela.add(lblTitulo);

        // Imagem da fórmula
        ImageIcon formulaIcon = new ImageIcon("b.png");
        lblFormula = new JLabel(formulaIcon);
        lblFormula.setBounds(300, 60, formulaIcon.getIconWidth(), formulaIcon.getIconHeight());
        tela.add(lblFormula);

        // Labels e TextFields para valor de a
        lblA = new JLabel("Valor de a:");
        lblA.setBounds(30, 70, 80, 25);
        tela.add(lblA);
        txtA = new JTextField();
        txtA.setBounds(120, 70, 150, 25);
        tela.add(txtA);

        // Labels e TextFields para valor de b
        lblB = new JLabel("Valor de b:");
        lblB.setBounds(30, 110, 80, 25);
        tela.add(lblB);
        txtB = new JTextField();
        txtB.setBounds(120, 110, 150, 25);
        tela.add(txtB);

        // Labels e TextFields para valor de c
        lblC = new JLabel("Valor de c:");
        lblC.setBounds(30, 150, 80, 25);
        tela.add(lblC);
        txtC = new JTextField();
        txtC.setBounds(120, 150, 150, 25);
        tela.add(txtC);

        // Botão Calcular
        btnCalcular = new JButton("Calcular");
        btnCalcular.setBounds(120, 190, 150, 30);
        btnCalcular.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                double a = Double.parseDouble(txtA.getText());
                double b = Double.parseDouble(txtB.getText());
                double c = Double.parseDouble(txtC.getText());

                double delta = Math.pow(b, 2) - 4 * a * c;
                txtDelta.setText("" + delta);

                if (delta < 0) {
                    txtX1.setText("Não existem raízes reais");
                    txtX2.setText("Não existem raízes reais");
                } else if (delta == 0) {
                    double x = -b / (2 * a);
                    txtX1.setText("" + x);
                    txtX2.setText("" + x);
                } else {
                    double x1 = (-b + Math.sqrt(delta)) / (2 * a);
                    double x2 = (-b - Math.sqrt(delta)) / (2 * a);
                    txtX1.setText("" + x1);
                    txtX2.setText("" + x2);
                }
            }
        });
        tela.add(btnCalcular);

        // Labels e TextFields para valor de delta
        lblDelta = new JLabel("Delta (Δ):");
        lblDelta.setBounds(30, 250, 80, 25);
        tela.add(lblDelta);
        txtDelta = new JTextField();
        txtDelta.setBounds(120, 250, 150, 25);
        txtDelta.setEditable(false);
        tela.add(txtDelta);

        // Labels e TextFields para valor de x1
        lblX1 = new JLabel("x1:");
        lblX1.setBounds(30, 290, 80, 25);
        tela.add(lblX1);
        txtX1.setBounds(120, 290, 150, 25);
        txtX1.setEditable(false);
        tela.add(txtX1);

        // Labels e TextFields para valor de x2
        lblX2 = new JLabel("x2:");
        lblX2.setBounds(30, 330, 80, 25);
        tela.add(lblX2);
        txtX2.setBounds(120, 330, 150, 25);
        txtX2.setEditable(false);
        tela.add(txtX2);

        //Deixando visivel na tela
        setVisible(true);
    }
}
