package bhaskaraform;

import javax.swing.*;


public class BhaskaraForm extends JFrame {

    public static void main(String[] args) {
        Bhaskara app = new Bhaskara();
        app.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }
}