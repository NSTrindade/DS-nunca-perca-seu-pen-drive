package testeinter;
import javax.swing.*;
public class TesteInter {
    public static void main(String[] args) {
        Inter app = new Inter(); 
        app.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }
    
}
