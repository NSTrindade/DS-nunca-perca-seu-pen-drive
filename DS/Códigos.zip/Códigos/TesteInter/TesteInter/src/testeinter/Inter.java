package testeinter;
import javax.swing.*;
import java.awt.*;
public class Inter extends JFrame {

JLabel r8, r1, r2, r3, r4, r5, r6, r7; 
JTextField texto1, texto2, texto3, texto4, t5, t6, t7; 

public Inter (){ 
super("Interface Gráfica"); 

Container tela = getContentPane(); 
setLayout(null); 
setResizable(false);
tela.setBackground(new Color(212, 208, 200));
r8 = new JLabel ("Cadastro de cliente");
r1 = new JLabel ("Nome"); 
r2 = new JLabel ("CPF"); 
r3 = new JLabel ("RG"); 
r4 = new JLabel ("Endereço"); 
r5 = new JLabel ("Cidade"); 
r6= new JLabel ("Estado"); 
r7 = new JLabel ("CEP"); 

r8.setForeground(Color.red);
r8.setFont(new Font("Calibri", Font.BOLD, 18));
r1.setFont(new Font("Calibri", Font.PLAIN, 14));
r2.setFont(new Font("Calibri", Font.PLAIN, 14));
r3.setFont(new Font("Calibri", Font.PLAIN, 14));
r4.setFont(new Font("Calibri", Font.PLAIN, 14));
r5.setFont(new Font("Calibri", Font.PLAIN, 14));
r6.setFont(new Font("Calibri", Font.PLAIN, 14));
r7.setFont(new Font("Calibri", Font.PLAIN, 14));

texto1 = new JTextField(50); 
texto2 = new JTextField(20); 
texto3 = new JTextField(20); 
texto4 = new JTextField(20); 
t5 = new JTextField(20);
t6 = new JTextField(20);
t7 = new JTextField(20);

r8.setBounds(110,20,200,20);
r1.setBounds(50,60,80,20); 
r2.setBounds(50,100,80,20); 
r3.setBounds(50,140,80,20); 
r4.setBounds(50,180,80,20); 
r5.setBounds(50,220,80,20);
r6.setBounds(50,260,80,20);
r7.setBounds(50,300,80,20);

texto1.setBounds(50,80,210,20); 
texto2.setBounds(50,120,110,20); 
texto3.setBounds(50,160,100,20); 
texto4.setBounds(50,200,210,20); 
t5.setBounds(50,240,200,20); 
t6.setBounds(50,280,180,20); 
t7.setBounds(50,320,150,20); 

tela.add(r8);
tela.add(r1); 
tela.add(r2); 
tela.add(r3); 
tela.add(r4);
tela.add(r5); 
tela.add(r6);
tela.add(r7);

tela.add(texto1); 
tela.add(texto2); 
tela.add(texto3); 
tela.add(texto4); 
tela.add(t5); 
tela.add(t6); 
tela.add(t7); 

setSize(400, 450); 
setVisible(true); 
setLocationRelativeTo(null);

}
}
