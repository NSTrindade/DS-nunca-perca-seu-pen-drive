package testeprimeirajanela; 

import javax.swing.*; // Importa todas as classes do pacote javax.swing para criar interfaces gráficas

public class TestePrimeiraJanela { 
    public static void main(String[] args) { // Método main: ponto de entrada do programa
        PrimeiraJanela app = new PrimeiraJanela(); // Cria uma instância da classe PrimeiraJanela (inicializa a janela)
        app.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); // Configura o comportamento ao fechar a janela (encerra o programa)
    } 
} 
