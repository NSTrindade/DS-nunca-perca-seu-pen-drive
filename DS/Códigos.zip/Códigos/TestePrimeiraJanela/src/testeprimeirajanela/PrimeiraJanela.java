package testeprimeirajanela;
import javax.swing.*; // Importa todas as classes do pacote javax.swing para criar interfaces gráficas

public class PrimeiraJanela extends JFrame { // Declaração da classe que herda de JFrame (janela básica do Swing)
    
    public PrimeiraJanela() { // Construtor da classe PrimeiraJanela
        super("Nossa primeira janela"); // Chama o construtor da classe pai (JFrame) e define o título da janela
        setSize(300, 150); // Define o tamanho da janela (largura: 300px, altura: 150px)
        setVisible(true); // Torna a janela visível na tela
    } 
} 
