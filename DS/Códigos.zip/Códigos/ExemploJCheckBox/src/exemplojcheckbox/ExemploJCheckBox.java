package exemplojcheckbox;

import java.awt.event.*;
import javax.swing.*;
import java.awt.*;// Import for Swing components

public class ExemploJCheckBox extends JFrame {
    JCheckBox primeira, segunda, terceira, quarta, quinta;
    JLabel vazio; // This label will show the selected items
    JButton botao; // Added button from the second image
    JLabel rotulo; // Moved rotulo declaration here to be accessible later if needed

    public ExemploJCheckBox() {
        super("Exemplo de um JCheckBox");
        Container tela = getContentPane();
        tela.setLayout(null); // Using absolute positioning

        // Label asking the question
        rotulo = new JLabel("Quais suas linguagens favoritas? ");
        rotulo.setBounds(40, 30, 250, 20); // Slightly increased width for text

        // --- Checkboxes ---
        primeira = new JCheckBox("Java");
        primeira.setMnemonic(KeyEvent.VK_J);
        primeira.setBounds(40, 60, 60, 20);
        primeira.setSelected(false); // Explicitly set initial state (from 2nd image)
        primeira.setForeground(Color.BLUE); // Set text color (from 2nd image)

        segunda = new JCheckBox("C++");
        segunda.setMnemonic(KeyEvent.VK_C);
        segunda.setBounds(110, 60, 60, 20); // Adjusted X position slightly

        terceira = new JCheckBox("Delphi");
        terceira.setMnemonic(KeyEvent.VK_D);
        terceira.setBounds(180, 60, 70, 20); // Adjusted X position slightly

        quarta = new JCheckBox("Visual Basic");
        quarta.setMnemonic(KeyEvent.VK_V);
        quarta.setBounds(260, 60, 100, 20); // Adjusted X position slightly

        quinta = new JCheckBox("Python");
        quinta.setMnemonic(KeyEvent.VK_P);
        quinta.setBounds(370, 60, 80, 20); // Adjusted X position slightly

        // --- Button ---
        botao = new JButton("Exibir");
        botao.setBounds(200, 150, 100, 20);

        // --- Label to display results ---
        vazio = new JLabel(""); // Initialized empty (from 2nd image)
        // Adjusted bounds based on the second image, looks like a wide area for results
        vazio.setBounds(40, 100, 400, 20); // Adjusted Y and width for better placement below checkboxes

        // --- ActionListener for the button ---
        botao.addActionListener((ActionEvent e) -> {
            String escolhas = ""; // String to hold selected languages
            // Check each checkbox and append its text if selected
            if (primeira.isSelected() == true) { // Using == true as in the image
                escolhas = escolhas + " " + primeira.getText();
            }
            if (segunda.isSelected() == true) {
                escolhas = escolhas + " " + segunda.getText();
            }
            if (terceira.isSelected() == true) {
                escolhas = escolhas + " " + terceira.getText();
            }
            if (quarta.isSelected() == true) {
                escolhas = escolhas + " " + quarta.getText();
            }
            if (quinta.isSelected() == true) {
                escolhas = escolhas + " " + quinta.getText();
            }
            
            // Display the result in the 'vazio' label
            // Corrected syntax from image: removed extra )};
            vazio.setText("Você escolheu:" + escolhas);
        } // End of ActionListener anonymous class
        ); // End of addActionListener call

        // --- Add components to the content pane ---
        tela.add(rotulo);
        tela.add(primeira);
        tela.add(segunda);
        tela.add(terceira);
        tela.add(quarta);
        tela.add(quinta);
        tela.add(botao);
        tela.add(vazio); // Add the result label

        // --- JFrame settings ---
        setSize(500, 300); // Set window size (from 2nd image)
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); // Added for proper closing
        setVisible(true); // Make the window visible
    }

    // --- Main method to run the application ---
    public static void main(String args[]) {
        ExemploJCheckBox app = new ExemploJCheckBox();
        // No need for app.show() - setVisible(true) in constructor handles it
    }
}
