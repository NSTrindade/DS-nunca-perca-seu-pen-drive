package testejanela;
import javax.swing.*; // Importa todas as classes do pacote javax.swing para criar interfaces gráficas
import java.awt.*; // Importa todas as classes do pacote java.awt para trabalhar com elementos gráficos, como layouts e containers

public class Janela extends JFrame { // Declaração da classe Janela, que herda de JFrame (janela básica do Swing)
    JLabel rotulo1, rotulo2, rotulo3, rotulo4; // Declaração de variáveis para os rótulos (labels)
    JTextField texto1, texto2, texto3, texto4; // Declaração de variáveis para os campos de texto (text fields)

    public Janela() { // Construtor da classe Janela
        super("Exemplo com JTextField"); // Chama o construtor da classe pai (JFrame) e define o título da janela
        Container tela = getContentPane(); // Obtém o container principal da janela (área onde os componentes são exibidos)
        setLayout(null); // Define o layout como nulo para permitir posicionamento manual dos componentes

        // Cria os rótulos (labels) com os textos "Nome", "Idade", "Telefone" e "Celular"
        rotulo1 = new JLabel("Nome");
        rotulo2 = new JLabel("Idade");
        rotulo3 = new JLabel("Telefone");
        rotulo4 = new JLabel("Celular");

        // Cria os campos de texto (text fields) com larguras específicas
        texto1 = new JTextField(50); // Campo para o nome (largura: 50 caracteres)
        texto2 = new JTextField(3); // Campo para a idade (largura: 3 caracteres)
        texto3 = new JTextField(10); // Campo para o telefone (largura: 10 caracteres)
        texto4 = new JTextField(10); // Campo para o celular (largura: 10 caracteres)

        // Define as posições e tamanhos dos rótulos na janela usando setBounds(x, y, largura, altura)
        rotulo1.setBounds(50, 20, 80, 20); // Posiciona o rótulo "Nome"
        rotulo2.setBounds(50, 60, 80, 20); // Posiciona o rótulo "Idade"
        rotulo3.setBounds(50, 100, 120, 20); // Posiciona o rótulo "Telefone"
        rotulo4.setBounds(50, 140, 80, 20); // Posiciona o rótulo "Celular"
        
        rotulo1.setForeground(Color.red); // Define a cor do texto do rótulo "Nome" como vermelho
        rotulo2.setForeground(Color.blue); // Define a cor do texto do rótulo "Idade" como azul
        rotulo3.setForeground(new Color(190, 152, 142)); // Define a cor do texto do rótulo "Telefone" usando um tom personalizado (RGB)
        rotulo4.setForeground(new Color(201, 200, 100)); // Define a cor do texto do rótulo "Celular" usando outro tom personalizado (RGB)

        rotulo1.setFont(new Font("Arial", Font.BOLD, 14)); // Define a fonte do rótulo "Nome" como Arial, negrito, tamanho 14
        rotulo2.setFont(new Font("Comic Sans MS", Font.BOLD, 16)); // Define a fonte do rótulo "Idade" como Comic Sans MS, negrito, tamanho 16
        rotulo3.setFont(new Font("Courier New", Font.BOLD, 18)); // Define a fonte do rótulo "Telefone" como Courier New, negrito, tamanho 18
        rotulo4.setFont(new Font("Times New Roman", Font.BOLD, 20)); // Define a fonte do rótulo "Celular" como Times New Roman, negrito, tamanho 20

        // Define as posições e tamanhos dos campos de texto na janela usando setBounds(x, y, largura, altura)
        texto1.setBounds(140, 20, 200, 20); // Posiciona o campo de texto para o nome
        texto2.setBounds(140, 60, 20, 20); // Posiciona o campo de texto para a idade
        texto3.setBounds(140, 100, 80, 20); // Posiciona o campo de texto para o telefone
        texto4.setBounds(140, 140, 80, 20); // Posiciona o campo de texto para o celular

        // Adiciona os rótulos e campos de texto ao container principal da janela
        tela.add(rotulo1);
        tela.add(rotulo2);
        tela.add(rotulo3);
        tela.add(rotulo4);
        tela.add(texto1);
        tela.add(texto2);
        tela.add(texto3);
        tela.add(texto4);

        setSize(400, 250); // Define o tamanho da janela (largura: 400px, altura: 250px)
        setVisible(true); // Torna a janela visível
        setLocationRelativeTo(null); // Centraliza a janela na tela
    
    } 
} 