package testejanela; 

import javax.swing.*; // Importa todas as classes do pacote javax.swing para criar interfaces gráficas

public class TesteJanela { 
    public static void main(String[] args) { // Método main: ponto de entrada do programa
        Janela app = new Janela(); // Cria uma instância da classe JanelaTamanhos (inicializa a janela)
        app.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); // Configura o comportamento ao fechar a janela (encerra o programa)
    }
} 
