package exemplojradiobutton;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class ExemploJRadioButton extends JFrame {
    // Declare components at class level
    JRadioButton primeira, segunda, terceira, quarta, quinta;
    JLabel rotulo, rotulo2;
    JButton exibir;
    ButtonGroup grupo;

    public ExemploJRadioButton() {
        super("Exemplo de um JRadioButton"); // Set window title
        Container tela = getContentPane();
        tela.setLayout(null); // Use absolute positioning

        // --- Create Components ---

        // Labels
        rotulo = new JLabel("Escolha uma cidade: ");
        rotulo2 = new JLabel(""); // Label to display the result, initially empty

        // Button
        exibir = new JButton("Exibir");

        // Radio Buttons
        primeira = new JRadioButton("Rio de Janeiro");
        segunda = new JRadioButton("São Paulo");
        terceira = new JRadioButton("Minas Gerais");
        quarta = new JRadioButton("Amazonas");
        quinta = new JRadioButton("Rio Grande do Sul");

        // Button Group (to ensure only one radio button is selected)
        grupo = new ButtonGroup();
        grupo.add(primeira);
        grupo.add(segunda);
        grupo.add(terceira);
        grupo.add(quarta);
        grupo.add(quinta);

        // --- Set Mnemonics (Keyboard Shortcuts) ---
        // Note: Mnemonics seem arbitrarily chosen in the example
        primeira.setMnemonic(KeyEvent.VK_J);
        segunda.setMnemonic(KeyEvent.VK_C);
        terceira.setMnemonic(KeyEvent.VK_D);
        quarta.setMnemonic(KeyEvent.VK_V);
        quinta.setMnemonic(KeyEvent.VK_P);

        // --- Position Components (setBounds) ---
        rotulo.setBounds(50, 20, 200, 20);   // Label asking the question
        rotulo2.setBounds(50, 240, 400, 20); // Label to show the result (Adjusted X for alignment)
        exibir.setBounds(200, 200, 120, 20); // Button position

        primeira.setBounds(50, 50, 150, 20); // Radio button positions (Adjusted width slightly)
        segunda.setBounds(50, 80, 150, 20);
        terceira.setBounds(50, 110, 150, 20);
        quarta.setBounds(50, 140, 150, 20);
        quinta.setBounds(50, 170, 200, 20);  // Wider for longer text

        // --- Add ActionListener to the Button ---
        exibir.addActionListener(
            new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    // Check which radio button is selected and update rotulo2
                    // Note: Using == true as in the image, although !isSelected() is common
                    if (primeira.isSelected() == true) {
                        rotulo2.setText("A cidade escolhida foi: " + primeira.getText());
                    }
                    if (segunda.isSelected() == true) {
                        rotulo2.setText("A cidade escolhida foi: " + segunda.getText());
                    }
                    if (terceira.isSelected() == true) {
                        rotulo2.setText("A cidade escolhida foi: " + terceira.getText());
                    }
                    if (quarta.isSelected() == true) {
                        rotulo2.setText("A cidade escolhida foi: " + quarta.getText());
                    }
                    if (quinta.isSelected() == true) {
                        rotulo2.setText("A cidade escolhida foi: " + quinta.getText());
                    }
                    // Corrected syntax: removed extra )); }} from the original image's last line inside listener
                } // end actionPerformed
            } // end ActionListener anonymous class
        ); // end addActionListener

        // --- Add Components to the Content Pane ('tela') ---
        tela.add(rotulo);
        tela.add(primeira);
        tela.add(segunda);
        tela.add(terceira);
        tela.add(quarta);
        tela.add(quinta);
        tela.add(exibir);
        tela.add(rotulo2); // Add the result label

        // --- Final JFrame Setup ---
        setSize(500, 300);                // Set window size
        setLocationRelativeTo(null);      // Center window on screen
        setVisible(true);                 // Make window visible
        // setDefaultCloseOperation is set in main()
    }

    // --- Main Method (Entry Point) ---
    public static void main(String args[]) {
        ExemploJRadioButton app = new ExemploJRadioButton();
        // Set close operation here as shown in the image
        app.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }
}