
package exemplobotao;
import javax.swing.*;
public class ExemploBotao {
    public static void main(String[] args) {
        Botao app = new Botao(); 
        app.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }
    
}
