
package exemplobotao;


import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class Botao extends JFrame{
    
ImageIcon icone;
JButton botao, b, b2;

public Botao(){ 
    
super("Exemplo com JButton"); 
Container tela = getContentPane(); 
setLayout(null); 

icone = new ImageIcon("f.png");

botao = new JButton("Novo");
b = new JButton("Abrir", icone);
b2 = new JButton(icone);

botao.setBounds(150,20,100,20);  
tela.add(botao);

b.setBounds(150,60,100,20);  
tela.add(b);

b2.setBounds(150,100,100,20);  
tela.add(b2);



setSize(400, 250); 
setVisible(true); 
setLocationRelativeTo(null); 
    
}}
